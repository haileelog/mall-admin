package cafe.jjdev.mall.service;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import cafe.jjdev.mall.mapper.BoardCommentMapper;
import cafe.jjdev.mall.mapper.BoardFileMapper;
import cafe.jjdev.mall.mapper.BoardMapper;
import cafe.jjdev.mall.vo.Board;
import cafe.jjdev.mall.vo.BoardComment;
import cafe.jjdev.mall.vo.BoardFile;
import cafe.jjdev.mall.vo.BoardRequest;

@Service
@Transactional
public class BoardService {
	@Autowired private BoardMapper boardMapper;
	@Autowired private BoardCommentMapper boardCommentMapper;
	@Autowired private BoardFileMapper boardFileMapper;
	
	// 댓글리스트
	public Map<String, Object> getBoardAndCommentListAndFileList(int boardNo) {
		Board board = boardMapper.selectBoard(boardNo);
		List<BoardComment> boardCommentList = boardCommentMapper.selectBoardCommentListByBoardNo(boardNo);
		List<BoardFile> boardFileList = boardFileMapper.selectBoardFileListByBoardNo(boardNo);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("board", board);
		map.put("boardCommentList", boardCommentList);		
		map.put("boardFileList", boardFileList);
		return map;
	}
	
	// 리스트 , 페이징처리
	public Map<String, Object> getBoardList(int currentPage){
		// currentPage를 바로 쓸 수 없으므로 요청 가공해줘야함
		final int ROW_PER_PAGE = 10;
		final int beginRow = (currentPage-1)*ROW_PER_PAGE;
		
		// selectBoardList가 하나의 값만 받으므로 map사용해준다
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("beginRow", beginRow);
		map.put("rowPerPage", ROW_PER_PAGE);
		
		// Mapper 메서드 2개 호출 -> 쿼리 2번 호출
		List<Board> list = boardMapper.selectBoardList(map);
		int boardCount = boardMapper.selectBoardCount();
		int lastPage = boardCount/ROW_PER_PAGE;
		if(boardCount%ROW_PER_PAGE !=0) {
			lastPage++;
		}
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("list", list);
		returnMap.put("lastPage", lastPage);
		returnMap.put("boardCount", boardCount);		
		return returnMap;
	}
	
	// 수정
	public int modifyBoard(Board board) {
		return boardMapper.updateBoard(board);
	}
	
	// 글작성
	public void addBoard(BoardRequest boardRequest) {
		
		// 1. BoardRequest -> Board
		Board board = new Board();
		board.setBoardTitle(boardRequest.getBoardTitle());
		board.setBoardPw(boardRequest.getBoardPw());
		board.setBoardContent(boardRequest.getBoardContent());
		board.setBoardUser(boardRequest.getBoardUser());
		System.out.println("[BoardService.addBoard] board : "+ board);
		
		boardMapper.insertBoard(board);  // board.setBoardNo(실제 insert되었던 autoincrement값);
		
		// 2. BoardRequest -> MultipartFile -> BoardFile
		MultipartFile multipartFile = boardRequest.getBoardFile();
		System.out.println("[BoardService.addBoard] multipartFile : "+ multipartFile);
		
		if(multipartFile.isEmpty() == false) {
		String contentType = multipartFile.getContentType();
		String name = multipartFile.getName();
		String originalFileName = multipartFile.getOriginalFilename();
		long size = multipartFile.getSize();
		System.out.println("contentType : "+contentType);
		System.out.println("name : "+name);
		System.out.println("originalFileName : "+originalFileName);
		System.out.println("size : "+size);
		
			// abc.hwp <- UUID 이용하기
			int i = originalFileName.lastIndexOf(".");
			String originName = originalFileName.substring(0,i);
			String ext = originalFileName.substring(i+1);
			UUID uuid = UUID.randomUUID();
			String saveName = uuid.toString();
		
		BoardFile boardFile = new BoardFile();
		boardFile.setBoardFileSize(multipartFile.getSize());
		boardFile.setBoardFileType(multipartFile.getContentType());
		boardFile.setBoardFileOriginName(originName);
		boardFile.setBoardFileSaveName(saveName);
		boardFile.setBoardFileExt(ext);
	    boardFile.setBoardNo(board.getBoardNo());
		System.out.println("[BoardService.addBoard] boardNo : "+ board.getBoardNo());
		System.out.println("[BoardService.addBoard] boardFile : "+ boardFile);

		boardFileMapper.insertBoardFile(boardFile);
		
		// 3. 서버폴더에 파일 저장 
		String path = "c:/temp/";
		File file = new File(path+saveName+"."+ext);  // 빈파일
		
		try {
			multipartFile.transferTo(file);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		} 
	}		
	}
	
	// 글삭제 및 댓글전체삭제
	public void removeBoard(Board board) {
		int commentResult = boardCommentMapper.deleteBoardCommentByBoardNo(board.getBoardNo());		
		int boardResult = boardMapper.deleteBoard(board);
	}
	
	// 댓글하나 삭제
	public void removeBoardByBoardCommentNo(BoardComment boardComment) {
		int deleteCommentResult = boardCommentMapper.deleteBoardCommentByCommentNo(boardComment.getBoardCommentNo());
	}
	
	// 선택
	public Board getBoard(int boardNo) {
		return boardMapper.selectBoard(boardNo);
	}
}
